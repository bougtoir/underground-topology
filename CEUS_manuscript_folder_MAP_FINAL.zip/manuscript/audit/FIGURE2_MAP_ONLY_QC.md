# Figure 2 map-only QC
- Panel (a): full Japan extent (122–150.5E, 23.5–46.5N) incl. Hokkaido,
  Nansei Islands, and Kuril/Northern Territories geometry drawn from
  geoBoundaries RUS ADM0 (neutral grey national boundary treatment;
  disputed-area boundary conventions follow the source dataset).
- Main map: exactly 3 identical unlabeled red markers (Sano 139.58E/36.33N,
  Kudamatsu 131.87E/34.02N, Yasu 136.03E/35.07N).
- Single upper-left inset (axes fraction, does not cover any marker):
  W-Honshu–Tochigi crop 129–142.5E/31.5–38.6N, same symbols, labels Sano /
  Kudamatsu / Yasu, leader lines, no label overlap (visually inspected).
- Data: geoBoundaries JPN ADM1 + RUS ADM0 (CC-BY-4.0, wmgeolab
  releaseData 9469f09) persisted in data/raw/geoboundaries/ with hashes;
  script scripts/p20_geographic_context_fig.py; EPSG:4326 with 36deg
  aspect correction.
- Panels (b)-(d) unchanged; caption updated for inset + ADM0 attribution.
- Frozen results untouched; no other edits.
