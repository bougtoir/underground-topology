# FINAL_HANDOFF (five-point/three-point final)
GATE VERDICT: GO. Commit: see git log on devin/1791669486-caie-retarget.
130-kVA: stale v1 artifact corrected via targeted rerun (XFORM_KVA=130 on
frozen v2 reconstruction): VoF% 0.0150/0.3196/0.2258; feasible 352/82/97.
Tolerance: 2 solver-precision positives (~1e-15%) classed zero under declared
rule >1e-4; 24 substantive positives; 95.7% zero mass.
Self-adjustment rho: removed as NA everywhere. tld: endogenous footnote.
Figures: Fig1 and Fig6 redesigned; all 300-dpi PNG+TIFF.
Novelty boundary: see audit/CEUS_NOVELTY_BOUNDARY.md — GO.
CEUS: JCR Q1 verified multi-source; subscription $0 mandatory fees.
Files for submission: manuscript_ceus_final.docx (or inline version if
permitted), supplement_ceus.docx, cover letter, highlights, declarations,
data/code availability, figures/{png,tiff}, tables/.
