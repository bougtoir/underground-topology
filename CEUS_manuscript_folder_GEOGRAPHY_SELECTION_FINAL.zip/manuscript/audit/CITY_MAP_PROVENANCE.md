# Figure 2a provenance
- Boundary data: geoBoundaries JPN ADM1 (CC-BY-4.0, William & Mary geoLab,
  releaseData commit 9469f09), raw file data/raw/geoboundaries/
  geoBoundaries-JPN-ADM1.geojson (SHA-256 fc30ddd3..., 62,675,304 B,
  retrieved 2026-10-11 UTC).
- CRS: EPSG:4326; aspect corrected for 36 deg N. Zone centroids computed
  from data/processed/<city>/zone.geojson; markers at municipal locations
  (Sano 139.58E/36.33N; Kudamatsu 131.87E/34.02N; Yasu 136.03E/35.07N).
- Script: scripts/p20_geographic_context_fig.py (GeoPandas+Matplotlib,
  300 dpi PNG/TIFF + PDF master).
